export * from '@pristine/components/fullscreen/public-api';
