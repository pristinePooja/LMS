export type PristineDrawerMode =
    | 'over'
    | 'side';

export type PristineDrawerPosition =
    | 'left'
    | 'right';
