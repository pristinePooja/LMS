export * from '@pristine/components/highlight/public-api';
