import { Version } from '@pristine/version/version';

export const PRISTINE_VERSION = new Version('14.1.1').full;
