export * from '@pristine/services/splash-screen/splash-screen.module';
export * from '@pristine/services/splash-screen/splash-screen.service';
