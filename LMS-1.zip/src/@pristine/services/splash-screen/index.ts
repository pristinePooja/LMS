export * from '@pristine/services/splash-screen/public-api';
