export * from '@pristine/services/config/config.module';
export * from '@pristine/services/config/config.service';
