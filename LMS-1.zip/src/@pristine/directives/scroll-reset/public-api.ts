export * from '@pristine/directives/scroll-reset/scroll-reset.directive';
export * from '@pristine/directives/scroll-reset/scroll-reset.module';
